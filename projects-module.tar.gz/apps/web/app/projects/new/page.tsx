import AppShell from "../../../components/layout/AppShell";

export default function NewProjectPage() {
  return (
    <AppShell>
      <h1 style={{ color: "white" }}>New Project</h1>
    </AppShell>
  );
}